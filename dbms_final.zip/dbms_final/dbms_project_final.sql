-- 1.	Show the percentage of wins of each bidder in the order of highest to lowest percentage.

select distinct BIDDER_ID,total_match_won,total_matches_bid,(total_match_won/total_matches_bid)*100 percentage_match_won from 
(select distinct *,count(case when status_of_bid ="won" then status_of_bid end )over(partition by BIDDER_ID) total_match_won,
count(BIDDER_ID)over(partition by BIDDER_ID) total_matches_bid from
(select distinct *,if(BID_TEAM=team_id,"won","lost") status_of_bid from
(select BIDDER_ID,BID_TEAM,team_id,team_won,bd.SCHEDULE_ID from 
(select match_id,team_won,team_id  from
(select MATCH_ID,substring_index(substring_index(WIN_DETAILS," ",2)," ",-1) team_won from ipl_match) s 
join ipl_team t on s.team_won=t.remarks)s2 
join ipl_match_schedule ms on s2.match_id=ms.match_id
join ipl_bidding_details bd on bd.SCHEDULE_ID=ms.SCHEDULE_ID
)s3)s4)s5 order by percentage_match_won desc;


-- 2.	Display the number of matches conducted at each stadium with the stadium name and city.
select STADIUM_ID,STADIUM_NAME,CITY,total_matches_played from 
(select distinct STADIUM_ID,count(STADIUM_ID)over(partition by STADIUM_ID) total_matches_played from ipl_match_schedule where status!="cancelled") t 
join ipl_stadium st using(STADIUM_ID);

-- 3.	In a given stadium, what is the percentage of wins by a team which has won the toss?
select *,(toss_and_match_win/total_match)*100 percentage from
(select distinct STADIUM_ID,
count(case when match_winner_id =toss_winner_id  then toss_winner_id end )over(partition by STADIUM_ID) toss_and_match_win,
count(toss_winner_id)over(partition by STADIUM_ID) total_match  from
(select MATCH_ID,STADIUM_ID,match_winner_id,toss_winner_id from 
(select match_id,team_id as match_winner_id,toss_winner_id from
(select MATCH_ID,substring_index(substring_index(WIN_DETAILS," ",2)," ",-1) team_won ,
if(TOSS_WINNER=1,TEAM_ID1,TEAM_ID2) toss_winner_id,WIN_DETAILS from ipl_match ) s 
join ipl_team t on s.team_won=t.remarks)s1 join ipl_match_schedule ms using(MATCH_ID) 
where status!="cancelled")s2)s3
;


-- 4.	Show the total bids along with the bid team and team name.

select distinct BID_TEAM,TEAM_NAME,count(BIDDER_ID)over(partition by BID_TEAM) individual_total_bids
from ipl_bidding_details bid join ipl_team team 
on bid.BID_TEAM = team.TEAM_ID ;

-- 5.	Show the team id who won the match as per the win details.
select match_id,team_id,team_won,WIN_DETAILS from
(select MATCH_ID,substring_index(substring_index(WIN_DETAILS," ",2)," ",-1) team_won,WIN_DETAILS from ipl_match) s 
join ipl_team t on s.team_won=t.remarks;


-- 6.	Display total matches played, total matches won and total matches lost by the team along with its team name.

select temp12.team_id,team_name,total_matches,win_count,(total_matches-win_count) as loss_count from
(select team_id1 as team_id,(matches_id1+matches_id2) total_matches from
(select team_id1,count(team_id1) matches_id1 from ipl_match
group by team_id1)temp10 join
(select team_id2,count(team_id2) matches_id2 from ipl_match
group by team_id2)temp11
on team_id1=team_id2)temp12
join 
(select team_id,team_name,win_count from ipl_team join
(select * from 
(select winner,count(winner) as win_count from
(select trim(substring(win_details,6,instr(win_details,"won")-6)) as winner from ipl_match)temp1
group by winner)temp2)temp3
on winner=remarks)temp4
on temp12.team_id=temp4.team_id;





-- 7.	Display the bowlers for the Mumbai Indians team.

select a.PLAYER_ID, PLAYER_NAME
from ipl_team_players a join ipl_player b using(PLAYER_ID)
where PLAYER_ROLE like '%bowler%' and TEAM_ID=(select TEAM_ID from ipl_team where TEAM_NAME like '%mumbai%');

-- 8.	How many all-rounders are there in each team, Display the teams with more than 4 

select  TEAM_ID,TEAM_NAME,count(*)total_number_of_all_rounders 
from ipl_team_players a join ipl_team b using(TEAM_ID)
where PLAYER_ROLE like '%all%'
group by TEAM_ID 
having total_number_of_all_rounders>4 order by total_number_of_all_rounders desc ;

-- 9 Write a query to get the total bidders points for each bidding status of those bidders who bid on CSK when it won the match in M. 
-- Chinnaswamy Stadium bidding year-wise.
-- Note the total bidders’ points in descending order and the year is bidding year.
-- Display columns: bidding status, bid date as year, total bidder’s points

select bp.BIDDER_ID, year(BID_DATE),TOTAL_POINTS from 
(select * from 
(select distinct * from
(select match_id,team_id,team_won,WIN_DETAILS from
(select MATCH_ID,substring_index(substring_index(WIN_DETAILS," ",2)," ",-1) team_won,WIN_DETAILS from ipl_match) s 
join ipl_team t on s.team_won=t.remarks where s.team_won="CSK")s1 
join ipl_match_schedule ms using(MATCH_ID) where 
ms.status!="cancelled" and ms.STADIUM_ID=(select STADIUM_ID from ipl_stadium where city="Bengaluru"))s2 
join ipl_bidding_details bd using(SCHEDULE_ID) )s3 
join ipl_bidder_points bp on year(BID_DATE)=bp.TOURNMT_ID where TEAM_ID=BID_TEAM
group by BIDDER_ID,year(BID_DATE),TOTAL_POINTS ;



-- 10.	Extract the Bowlers and All Rounders those are in the 5 highest number of wickets.
-- Note 
-- 1. use the performance_dtls column from ipl_player to get the total number of wickets
-- 2. Do not use the limit method because it might not give appropriate results when players have the same number of wickets
-- 3.	Do not use joins in any cases.
-- 4.	Display the following columns teamn_name, player_name, and player_role.


select * from 
(select PLAYER_ID,PLAYER_NAME,wickets_taken+0,dense_rank()over(order by wickets_taken+0 desc) drnk from
(select player_name,PLAYER_ID, right(substring(PERFORMANCE_DTLS,instr(PERFORMANCE_DTLS,"wkt"),6),2) wickets_taken 
from ipl_player order by wickets_taken desc) t)t1 
where drnk<=5 and PLAYER_ID in(select PLAYER_ID from ipl_team_players where player_role like "%all%" or player_role like "%bowler%") ;


-- 11.	show the percentage of toss wins of each bidder and display the results in descending order based on the percentage

select BIDDER_ID,total_toss_win,total_matches_bid,(total_toss_win/total_matches_bid)*100 percentage_toss_win from 
(select distinct *,count(case when toss_win_status ="won" then toss_win_status end )over(partition by BIDDER_ID) total_toss_win,
count(BIDDER_ID)over(partition by BIDDER_ID) total_matches_bid from
(select BIDDER_ID, if(team_that_won_the_toss=BID_TEAM,"won","lost") toss_win_status from
(select BIDDER_ID,m.MATCH_ID,SCHEDULE_ID, if(TOSS_WINNER=1,TEAM_ID1,TEAM_ID2) team_that_won_the_toss,BID_TEAM 
from ipl_match_schedule ms join ipl_match m using(MATCH_ID) join ipl_bidding_details bd using(SCHEDULE_ID))t)t1)t2 
where toss_win_status="won" or total_toss_win=0 order by percentage_toss_win desc;






-- 12.	find the IPL season which has min duration and max duration.Output columns should be like the below:
-- Tournment_ID, Tourment_name, Duration column, Duration
select * from ipl_tournament;

select * from 
(select tournmt_id,tournmt_name,from_date,to_date,datediff(to_date,from_date) duration,
rank()over(order by datediff(to_date,from_date)) as rnk from ipl_tournament it order by duration)temp
where rnk=1 or rnk=10;

-- 13.	Write a query to display to calculate the total points month-wise for the 2018 bid year. 
-- sort the results based on total points in descending order and month-wise in ascending order.
-- Note: Display the following columns:
--    1.	Bidder ID, 2. Bidder Name, 3. bid date as Year, 4. bid date as Month, 5. Total points
--    Only use joins for the above query queries.

select brd.Bidder_id,brd.bidder_name,year(bid_date)bid_date_year,month(BID_DATE)bid_date_month, 
bp.total_points
from ipl_bidder_details brd join ipl_bidding_details bgd using(bidder_id)
join ipl_bidder_points bp using(bidder_id)
where year(bid_date)=2018
group by brd.Bidder_id,brd.bidder_name,year(bid_date),month(BID_DATE),bp.total_points
order by bp.total_points desc,month(BID_DATE) asc;


-- 14.	Write a query for the above question using sub queries by having the same constraints as the above question.
select bidder_id, (select bidder_name from ipl_bidder_details ibd where ibd.bidder_id=bd.bidder_id) as bidder_name,
year(bid_date)bid_date_year, monthname(bid_date)bid_date_month, 
(select total_points from ipl_bidder_points bp where bp.bidder_id=bd.bidder_id) total_points from ipl_bidding_details bd
where year(bid_date)=2018
group by bidder_id,bidder_name,bid_date_year,bid_date_month,total_points
order by total_points desc,bid_date_month asc;



-- 15.	Write a query to get the top 3 and bottom 3 bidders based on the total bidding points for the 2018 bidding year.
-- Output columns should be like:
-- Bidder Id, Ranks (optional), Total points, Highest_3_Bidders 
-- > columns contains name of bidder, Lowest_3_Bidders  
-- > columns contains name of bidder;

select *,if (drnk<=3,"top3_bidders","bottom3_bidders" )top3_and_bottom3_bidders from
(select bidder_id,total_points,dense_rank()over(order by total_points desc) drnk,
(select bidder_name from ipl_bidder_details where bidder_id=ibp.bidder_id) bidder_name
from  ipl_bidder_points ibp)t1 where drnk<=3 or drnk>13 ;

-- 16th question - triggers
#Table 1: Attributes 		Table 2: Attributes
#Student id, Student name, mail id, mobile no.	Student id, student name, mail id, mobile no.

create table if not exists student_details(
Student_id int primary key , 
Student_name varchar(10),
mail_id varchar(20),
mobile_no varchar(15));


create table if not exists Backup_student_details(
Student_id int primary key , 
Student_name varchar(10),
mail_id varchar(20),
mobile_no varchar(15),
    backup_timestamp timestamp default current_timestamp
);

delimiter //
create trigger Insert_Student_Backup
after insert on student_details
for each row
begin
    insert into Backup_student_details (Student_id, Student_name, mail_id, mobile_no)
    values (new.Student_id,new.Student_name, new.mail_id, new.mobile_no);
end;
//
delimiter ;


# 17 . List of RCB Batsmen in the season 
select player_name from
ipl_player p join ipl_team_players tp using(player_id)
join ipl_team t using(team_id)
where team_name like "%Royal Challengers Bangalore%" and player_role like "%Batsman%";

# 18 Performance details about the player Virat Kohli
select *from
ipl_player p join ipl_team_players tp using(player_id)
join ipl_team t using(team_id)
where player_name like "%virat%" ;

# 19 . Display team names which have won more then 8 matches
select team_name from ipl_team as it join ipl_team_standings as its on it.team_id =its.team_id
where matches_won >8 ;
# 20 . Prediction of match winner in next match for next season for match between RCB vs CSK based on 2017 and 2018 results
select * from ipl_team;
select * from ipl_match;
select * from ipl_match_schedule;

select count(match_id) total_match_between_rcbvscsk_in2018_2017,sum(rcbwins) rcb_wins,
(sum(rcbwins)/count(match_id))*100 possibility_of_rcb_winning_next_match_based_on_2017_2018_result from
(select im.match_id,team_id1,team_id2,win_details,if(win_details like "%rcb%",1,0) as rcbwins
from ipl_match im join ipl_match_schedule ims
on im.match_id=ims.match_id
where team_id1 in (1,7) and team_id2 in (1,7))temp;

# 21. use common table expression to fetch the wickets taken by all bowlers and all-rounders playing for rcb playing for RCB

with player_roles as
(select team_id,itp.player_id,player_role,substring_index(substring_index(substring_index(PERFORMANCE_DTLS," ",3)," ",-1),"-",-1)wickets_taken
from ipl_team_players itp join ipl_player ip using(PLAYER_ID))

select * from player_roles where team_id=(select team_id from ipl_team where REMARKS ="RCB")
 and (player_role like "%bowler%" or player_role like "%all%") order by wickets_taken+0 desc;
 






